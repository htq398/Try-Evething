#include "output.h"
#include "timer.h"
#include "delay.h"
void Motor_GPIO_Init(void)
{
GPIO_InitTypeDef Init_Instructure;
	RCC_APB2PeriphClockCmd(Motor_GPIO_CLK ,ENABLE );
	Init_Instructure.GPIO_Mode=GPIO_Mode_Out_PP;
	Init_Instructure.GPIO_Pin=Motor_PIN0;
	Init_Instructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(Motor_PORT,&Init_Instructure );

	Init_Instructure.GPIO_Pin=Motor_PIN1;
	GPIO_Init(Motor_PORT,&Init_Instructure );
	
	Init_Instructure.GPIO_Pin=Motor_PIN2;
	GPIO_Init(Motor_PORT,&Init_Instructure );
	
	Init_Instructure.GPIO_Pin=Motor_PIN3;
	GPIO_Init(Motor_PORT,&Init_Instructure );
	
}

void back(void)
{
TIM3_PWM_Init(2000);
TIM4_PWM_Init(2000);
Motor_PIN0_0;
Motor_PIN1_1;
	
Motor_PIN2_0 ;
Motor_PIN3_1;


}

//PA0~3�ӵ�L298N��IN1~4

void front(void)
{
TIM3_PWM_Init(2000);
TIM4_PWM_Init(2000);
Motor_PIN0_1;//PA0��1
Motor_PIN1_0;//PA1��0
	
Motor_PIN2_1;//PA2��1
Motor_PIN3_0;//PA3��0
}

void left(void)
{
	TIM3_PWM_Init(3200);
	


}

void right(void)
{

	
	TIM4_PWM_Init(3200);

}


void stop(void)
{
Motor_PIN0_0;
Motor_PIN1_0;
	
Motor_PIN2_0;
Motor_PIN3_0;
}


