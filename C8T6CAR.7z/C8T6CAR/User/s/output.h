#ifndef __OUTPUT_H
#define	__OUTPUT_H


#include "stm32f10x.h"
#include <stdio.h>

#define  Motor_PORT               GPIOA
#define  Motor_PIN0                GPIO_Pin_4
#define  Motor_GPIO_CLK           RCC_APB2Periph_GPIOA

#define  Motor_PORT               GPIOA
#define  Motor_PIN1                GPIO_Pin_5
#define  Motor_GPIO_CLK           RCC_APB2Periph_GPIOA

#define  Motor_PORT               GPIOA
#define  Motor_PIN2                GPIO_Pin_6
#define  Motor_GPIO_CLK           RCC_APB2Periph_GPIOA

#define  Motor_PORT               GPIOA
#define  Motor_PIN3                GPIO_Pin_7
#define  Motor_GPIO_CLK           RCC_APB2Periph_GPIOA



#define  Motor_PIN0_1             GPIO_SetBits(GPIOA,Motor_PIN0 ) 
#define  Motor_PIN0_0             GPIO_ResetBits(GPIOA,Motor_PIN0) 

#define  Motor_PIN1_1             GPIO_SetBits(GPIOA,Motor_PIN1 ) 
#define  Motor_PIN1_0             GPIO_ResetBits(GPIOA,Motor_PIN1) 

#define  Motor_PIN2_1             GPIO_SetBits(GPIOA,Motor_PIN2 ) 
#define  Motor_PIN2_0             GPIO_ResetBits(GPIOA,Motor_PIN2) 

#define  Motor_PIN3_1             GPIO_SetBits(GPIOA,Motor_PIN3 ) 
#define  Motor_PIN3_0             GPIO_ResetBits(GPIOA,Motor_PIN3) 




void back(void);
void front(void);
void left(void);
void right(void);
void stop(void);
void Motor_GPIO_Init(void);





#endif /* __OUTPUT_H */
