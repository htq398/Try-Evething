#ifndef __TIM_H
#define __TIM_H

#include "stm32f10x.h"
#define  TIM           TIM4
#define  TIM_CLK_FUN   RCC_APB1PeriphClockCmd
#define  TIM_CLK       RCC_APB1Periph_TIM4
#define  TIM_period    1000-1
#define  TIM_Perscaler 72-1
#define  TIM_IRQ               TIM4_IRQn
#define  TIM_IRQHandler        TIM4_IRQHandler


void TIM3_PWM_Init(u16 value);//value��0-7199֮��

void TIM4_PWM_Init(u16 value);//value��0-7199֮��
#endif 

