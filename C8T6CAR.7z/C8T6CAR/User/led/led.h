#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"
#define  LED_PORT               GPIOB
#define  LED_PIN                GPIO_Pin_12
#define  LED_GPIO_CLK           RCC_APB2Periph_GPIOB

#define OFF 0
#define  ON  1
#define digitalToggle(p,i) {p->ODR ^=i;} 

#define LED_TOGGLE		 digitalToggle(LED_PORT,LED_PIN)
void led_Init(void);
void LED(int x);
void Delay( uint32_t nCount);
void opp(void);

#endif 

