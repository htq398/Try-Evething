#include "led.h"
static int key=0;
void led_Init(void)
{
GPIO_InitTypeDef Init_Instructure;
		RCC_APB2PeriphClockCmd(LED_GPIO_CLK ,ENABLE );
	Init_Instructure.GPIO_Mode=GPIO_Mode_Out_PP;
	Init_Instructure.GPIO_Pin=LED_PIN;
	Init_Instructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(LED_PORT,&Init_Instructure );
	
}
void LED(int x) {
if(x) {GPIO_ResetBits(LED_PORT,LED_PIN);}
	else {GPIO_SetBits(LED_PORT,LED_PIN); }
}

void Delay( uint32_t nCount)	 //�򵥵���ʱ����
{
	for(; nCount != 0; nCount--);
}
void opp(void)
{
key=!key;
LED(key);
}
